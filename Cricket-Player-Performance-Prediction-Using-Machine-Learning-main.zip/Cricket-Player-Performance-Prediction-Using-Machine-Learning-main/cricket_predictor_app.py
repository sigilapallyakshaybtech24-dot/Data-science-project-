# ============================================================
# CRICKET PLAYER PERFORMANCE PREDICTOR — Streamlit GUI App
# CNN + LSTM Deep Learning Model
# Run: streamlit run cricket_predictor_app.py
# ============================================================

import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
import os, re, warnings, io
warnings.filterwarnings('ignore')

from sklearn.preprocessing import LabelEncoder, MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error

import tensorflow as tf
from tensorflow.keras.models import Model, load_model
from tensorflow.keras.layers import (
    Input, Dense, LSTM, Conv1D, MaxPooling1D,
    Flatten, Dropout, BatchNormalization
)
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau
from tensorflow.keras.optimizers import Adam

# ─────────────────────────────────────────────
# PAGE CONFIG
# ─────────────────────────────────────────────
st.set_page_config(
    page_title="Cricket Performance Predictor",
    page_icon="🏏",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ─────────────────────────────────────────────
# GLOBAL STYLES
# ─────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Rajdhani:wght@400;500;600;700&family=Inter:wght@300;400;500;600&display=swap');

html, body, [class*="css"] {
    font-family: 'Inter', sans-serif;
}

/* Dark cricket-themed background */
.stApp {
    background: linear-gradient(135deg, #0a0e1a 0%, #0d1b2a 50%, #091422 100%);
}

/* Hero header */
.hero-header {
    background: linear-gradient(120deg, #1a2744 0%, #0d2137 40%, #1a3a2e 100%);
    border: 1px solid #2a4a6b;
    border-radius: 16px;
    padding: 36px 40px 28px 40px;
    margin-bottom: 28px;
    position: relative;
    overflow: hidden;
}
.hero-header::before {
    content: "🏏";
    font-size: 140px;
    position: absolute;
    right: 30px;
    top: -10px;
    opacity: 0.07;
}
.hero-title {
    font-family: 'Rajdhani', sans-serif;
    font-size: 3rem;
    font-weight: 700;
    color: #f0f4ff;
    letter-spacing: 1px;
    margin: 0;
    line-height: 1.1;
}
.hero-subtitle {
    font-size: 1rem;
    color: #7a9bbf;
    margin-top: 8px;
    font-weight: 300;
    letter-spacing: 0.5px;
}
.hero-badge {
    display: inline-block;
    background: linear-gradient(90deg, #1db954, #17a849);
    color: white;
    font-size: 0.72rem;
    font-weight: 600;
    padding: 3px 12px;
    border-radius: 20px;
    letter-spacing: 1px;
    margin-top: 14px;
    text-transform: uppercase;
}

/* Cards */
.card {
    background: linear-gradient(145deg, #13213a, #0f1d30);
    border: 1px solid #1e3a5f;
    border-radius: 14px;
    padding: 24px 28px;
    margin-bottom: 20px;
}
.card-title {
    font-family: 'Rajdhani', sans-serif;
    font-size: 1.15rem;
    font-weight: 600;
    color: #89b4e8;
    text-transform: uppercase;
    letter-spacing: 1.5px;
    margin-bottom: 18px;
    padding-bottom: 10px;
    border-bottom: 1px solid #1e3a5f;
}

/* Predict button */
.stButton > button {
    width: 100%;
    background: linear-gradient(135deg, #1e8a4a, #15703c) !important;
    color: white !important;
    border: none !important;
    border-radius: 10px !important;
    font-family: 'Rajdhani', sans-serif !important;
    font-size: 1.2rem !important;
    font-weight: 700 !important;
    letter-spacing: 2px !important;
    padding: 14px !important;
    text-transform: uppercase !important;
    cursor: pointer !important;
    transition: all 0.2s ease !important;
    box-shadow: 0 4px 20px rgba(30, 138, 74, 0.35) !important;
}
.stButton > button:hover {
    background: linear-gradient(135deg, #25a85a, #1a8a47) !important;
    box-shadow: 0 6px 28px rgba(30, 138, 74, 0.55) !important;
    transform: translateY(-1px) !important;
}

/* Result box */
.result-box {
    background: linear-gradient(135deg, #0d2e1e, #0a2518);
    border: 1px solid #1e8a4a;
    border-left: 5px solid #1db954;
    border-radius: 14px;
    padding: 28px 32px;
    text-align: center;
    margin-top: 10px;
}
.result-runs {
    font-family: 'Rajdhani', sans-serif;
    font-size: 5rem;
    font-weight: 700;
    color: #1db954;
    line-height: 1;
}
.result-label {
    font-size: 0.85rem;
    color: #5a9a6e;
    letter-spacing: 2px;
    text-transform: uppercase;
    margin-top: 4px;
}
.result-sentence {
    font-size: 1.05rem;
    color: #c8e6d4;
    margin-top: 14px;
    font-weight: 400;
    line-height: 1.5;
}

/* Error / warning box */
.warn-box {
    background: #1a1000;
    border: 1px solid #b8860b;
    border-left: 5px solid #ffd700;
    border-radius: 10px;
    padding: 16px 20px;
    color: #ffd700;
    font-size: 0.92rem;
}

/* Metric cards */
.metric-card {
    background: linear-gradient(145deg, #111e32, #0d1929);
    border: 1px solid #1e3a5f;
    border-radius: 12px;
    padding: 18px 22px;
    text-align: center;
}
.metric-value {
    font-family: 'Rajdhani', sans-serif;
    font-size: 2rem;
    font-weight: 700;
    color: #89c4f4;
}
.metric-label {
    font-size: 0.72rem;
    color: #5a7a9a;
    letter-spacing: 1.5px;
    text-transform: uppercase;
    margin-top: 3px;
}

/* Selectbox, number input styling */
.stSelectbox label, .stNumberInput label {
    color: #7a9bbf !important;
    font-size: 0.82rem !important;
    letter-spacing: 1px !important;
    text-transform: uppercase !important;
    font-weight: 500 !important;
}
.stSelectbox > div > div {
    background-color: #0f1e33 !important;
    border: 1px solid #1e3a5f !important;
    border-radius: 8px !important;
    color: #d0e8ff !important;
}
.stNumberInput > div > div > input {
    background-color: #0f1e33 !important;
    border: 1px solid #1e3a5f !important;
    color: #d0e8ff !important;
    border-radius: 8px !important;
}

/* Sidebar */
[data-testid="stSidebar"] {
    background: linear-gradient(180deg, #0d1b2a, #091520);
    border-right: 1px solid #1e3a5f;
}

/* Tab underline */
.stTabs [data-baseweb="tab-list"] {
    background: transparent;
    border-bottom: 1px solid #1e3a5f;
}
.stTabs [data-baseweb="tab"] {
    color: #5a7a9a;
    font-family: 'Rajdhani', sans-serif;
    font-size: 1rem;
    letter-spacing: 1px;
    font-weight: 600;
}
.stTabs [aria-selected="true"] {
    color: #89c4f4 !important;
    border-bottom-color: #1db954 !important;
}

/* Divider */
hr { border-color: #1e3a5f; }

/* Hide Streamlit branding */
#MainMenu, footer { visibility: hidden; }
</style>
""", unsafe_allow_html=True)


# ─────────────────────────────────────────────
# CONSTANTS / DATASET FILE NAMES
# ─────────────────────────────────────────────
BATSMAN_FILE  = "Batsman_Data.csv"
BOWLER_FILE   = "Bowler_data.csv"
ODI_FILE      = "ODI_Match_Results.csv"
GROUND_FILE   = "Ground_Averages.csv"
MODEL_FILE    = "cricket_cnn_lstm_model.keras"

FEATURE_COLS  = None   # determined after loading
TARGET_COL    = "Runs"


# ─────────────────────────────────────────────
# DATA LOADING
# ─────────────────────────────────────────────
@st.cache_data(show_spinner=False)
def load_and_preprocess():
    """
    Preprocessing built exactly for the confirmed CSV structures:

    newplayer.csv  → primary source (has Player, Country, Runs, BF, SR, Overs, RPO, etc.)
    Batsman_Data.csv → supplementary (has Batsman col, not Player; merged on Match_ID)
    ODI_Match_Results.csv → adds Result, Country per match
    Ground_Averages.csv → adds ground RPO/Ave

    Root causes fixed vs previous version:
    - Runs column had "-" strings (DNB rows) → must coerce to numeric before filtering
    - Primary file is newplayer.csv, not Batsman_Data.csv
    - Overs filter was wiping too many rows; applied only after numeric coercion
    - dropna(inplace) after numeric conversion was emptying the frame
    """

    # ── 1. Determine primary file ──────────────────────────────────────
    # newplayer.csv has Player+Runs+BF+SR+Overs all in one place — use it
    PRIMARY = "newplayer.csv"
    if not os.path.exists(PRIMARY):
        if os.path.exists(BATSMAN_FILE):
            PRIMARY = BATSMAN_FILE
        else:
            csvs = [f for f in os.listdir('.') if f.endswith('.csv')]
            if not csvs:
                return None, ("No CSV dataset found. Place newplayer.csv (or Batsman_Data.csv) "
                              "in the same folder as cricket_predictor_app.py and restart.")
            PRIMARY = csvs[0]

    df = pd.read_csv(PRIMARY)

    # ── 2. Also load Batsman_Data.csv and merge for more training rows ─
    if os.path.exists(BATSMAN_FILE) and PRIMARY != BATSMAN_FILE:
        bat = pd.read_csv(BATSMAN_FILE)
        bat.rename(columns={'Batsman': 'Player'}, inplace=True)
        # Coerce numeric cols in batsman file
        for col in ['Runs', 'BF', 'SR', '4s', '6s']:
            if col in bat.columns:
                bat[col] = pd.to_numeric(
                    bat[col].astype(str).str.replace('*','',regex=False).str.strip(),
                    errors='coerce')
        bat = bat[bat['Runs'].notna()].copy()
        # Add Country from ODI file if available
        if os.path.exists(ODI_FILE):
            odi_c = pd.read_csv(ODI_FILE)[['Match_ID','Country']].drop_duplicates()
            bat = pd.merge(bat, odi_c, on='Match_ID', how='left')
        # Align columns and concatenate
        common = list(set(df.columns) & set(bat.columns))
        df = pd.concat([df[common], bat[common]], ignore_index=True)

    # ── 3. Rename Batsman → Player if needed ──────────────────────────
    if 'Batsman' in df.columns and 'Player' not in df.columns:
        df.rename(columns={'Batsman': 'Player'}, inplace=True)

    # ── 4. Strip leading 'v ' from Opposition ─────────────────────────
    if 'Opposition' in df.columns:
        df['Opposition'] = (df['Opposition'].astype(str)
                            .str.replace(r'^v\s*', '', regex=True)
                            .str.strip())

    # ── 5. Coerce ALL mixed-type columns to numeric ────────────────────
    for col in ['Runs', 'BF', 'SR', '4s', '6s', 'Overs', 'RPO',
                'Inns', 'Target', 'Team Runs']:
        if col in df.columns:
            df[col] = (df[col].astype(str)
                       .str.replace('*', '', regex=False)
                       .str.replace('/', '.', regex=False)
                       .str.strip())
            df[col] = pd.to_numeric(df[col], errors='coerce')

    # ── 6. Drop DNB / absent rows ─────────────────────────────────────
    df = df[df['Runs'].notna()].copy()

    # ── 7. Merge ODI results to add Country column if missing ─────────
    if 'Country' not in df.columns and os.path.exists(ODI_FILE):
        odi = pd.read_csv(ODI_FILE)[['Match_ID', 'Country']].drop_duplicates()
        df = pd.merge(df, odi, on='Match_ID', how='left')

    # ── 8. Merge Ground averages ──────────────────────────────────────
    if os.path.exists(GROUND_FILE) and 'Ground' in df.columns:
        grd = pd.read_csv(GROUND_FILE)[['Ground', 'RPO', 'Ave']].drop_duplicates('Ground')
        grd.rename(columns={'RPO': 'Ground_RPO', 'Ave': 'Ground_Ave'}, inplace=True)
        df = pd.merge(df, grd, on='Ground', how='left')

    # ── 9. Engineer richer features from what we have ─────────────────
    # These give the model real signal beyond just encoded IDs
    if 'BF' in df.columns and 'Runs' in df.columns:
        df['Runs_per_BF'] = df['Runs'] / (df['BF'].replace(0, np.nan))
    if 'BF' in df.columns and 'Overs' in df.columns:
        df['BF_per_Over'] = df['BF'] / (df['Overs'].replace(0, np.nan))
    if '4s' in df.columns and '6s' in df.columns:
        df['Boundary_Runs'] = df['4s'] * 4 + df['6s'] * 6
        df['Boundary_Pct']  = df['Boundary_Runs'] / (df['Runs'].replace(0, np.nan))

    # Player historical avg runs (strong predictor)
    if 'Player' in df.columns:
        player_avg = df.groupby('Player')['Runs'].transform('mean')
        player_std = df.groupby('Player')['Runs'].transform('std').fillna(0)
        df['Player_Avg_Runs'] = player_avg
        df['Player_Std_Runs'] = player_std
        df['Player_Match_Count'] = df.groupby('Player')['Runs'].transform('count')

    # Opposition average runs conceded (bowling strength signal)
    if 'Opposition' in df.columns:
        opp_avg = df.groupby('Opposition')['Runs'].transform('mean')
        df['Opp_Avg_Conceded'] = opp_avg

    # ── 10. Filter: only innings where Overs ≥ 5 ─────────────────────
    if 'Overs' in df.columns:
        df = df[df['Overs'].fillna(0) >= 5.0].copy()

    # ── 11. Drop meta / leakage columns ──────────────────────────────
    drop_candidates = ['Unnamed: 0', 'ID', 'Bat1', 'Ground', 'Start Date',
                       'Match_ID', 'Player_ID', 'Inns', 'Result',
                       'Country_ID', 'Margin', 'BR', 'Toss', 'Bat',
                       'Runs_per_BF']  # leaks target
    df.drop(columns=[c for c in drop_candidates if c in df.columns],
            inplace=True, errors='ignore')

    # ── 12. Encode categoricals ───────────────────────────────────────
    label_encoders = {}
    for col in ['Player', 'Opposition', 'Country']:
        if col in df.columns:
            le = LabelEncoder()
            df[col + '_enc'] = le.fit_transform(df[col].astype(str))
            label_encoders[col] = le

    # ── 13. Build final feature matrix ───────────────────────────────
    non_numeric = df.select_dtypes(exclude=[np.number]).columns.tolist()
    df.drop(columns=non_numeric, inplace=True, errors='ignore')

    if 'Runs' not in df.columns or len(df) == 0:
        return None, "Dataset empty or Runs column missing after preprocessing."

    # Drop columns where >50% values are NaN
    nan_frac = df.isnull().mean()
    bad_cols = nan_frac[nan_frac > 0.5].index.tolist()
    df.drop(columns=bad_cols, inplace=True, errors='ignore')

    # Fill remaining NaNs with column median
    df.fillna(df.median(numeric_only=True), inplace=True)
    df.replace([np.inf, -np.inf], 0, inplace=True)
    df.dropna(axis=1, how='all', inplace=True)

    feature_cols = [c for c in df.columns if c != 'Runs']

    if len(feature_cols) == 0:
        return None, "No feature columns remain after preprocessing."

    X = df[feature_cols].values.astype(np.float32)
    y = df['Runs'].values.astype(np.float32)

    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
    y = np.nan_to_num(y, nan=0.0)

    scaler_X = MinMaxScaler()
    scaler_y = MinMaxScaler()
    X_scaled = scaler_X.fit_transform(X)
    y_scaled = scaler_y.fit_transform(y.reshape(-1, 1)).flatten()

    X_scaled = np.nan_to_num(X_scaled, nan=0.0)
    y_scaled = np.nan_to_num(y_scaled, nan=0.0)

    # ── 12. Rebuild player/opposition lists from label encoders ───────
    players     = sorted(label_encoders['Player'].classes_.tolist())     if 'Player'     in label_encoders else []
    oppositions = sorted(label_encoders['Opposition'].classes_.tolist()) if 'Opposition' in label_encoders else []

    meta = {
        "df":             df,
        "feature_cols":   feature_cols,
        "label_encoders": label_encoders,
        "scaler_X":       scaler_X,
        "scaler_y":       scaler_y,
        "X_scaled":       X_scaled,
        "y_scaled":       y_scaled,
        "y":              y,
        "n_features":     len(feature_cols),
        "players":        players,
        "oppositions":    oppositions,
    }
    return meta, None


# ─────────────────────────────────────────────
# MODEL BUILD + TRAIN (cached)
# ─────────────────────────────────────────────
def build_cnn_lstm(input_shape):
    inputs = Input(shape=input_shape)
    x = Conv1D(64,  kernel_size=3, activation='relu', padding='same')(inputs)
    x = BatchNormalization()(x)
    x = Conv1D(128, kernel_size=3, activation='relu', padding='same')(x)
    x = BatchNormalization()(x)
    x = MaxPooling1D(pool_size=2, padding='same')(x)
    x = Dropout(0.2)(x)
    x = LSTM(128, return_sequences=True)(x)
    x = BatchNormalization()(x)
    x = Dropout(0.3)(x)
    x = LSTM(64,  return_sequences=False)(x)
    x = BatchNormalization()(x)
    x = Dropout(0.2)(x)
    x = Dense(64, activation='relu')(x)
    x = Dropout(0.2)(x)
    x = Dense(32, activation='relu')(x)
    out = Dense(1, activation='linear')(x)
    m = Model(inputs, out)
    m.compile(optimizer=Adam(0.001), loss='mse', metrics=['mae'])
    return m


@st.cache_resource(show_spinner=False)
def get_model(n_features, X_scaled, y_scaled):
    """Load saved model or train fresh. Cached so no retraining on predict clicks."""
    input_shape = (n_features, 1)

    if os.path.exists(MODEL_FILE):
        try:
            model = load_model(MODEL_FILE)
            return model, None, None, None
        except Exception:
            pass

    # Split
    X_tr, X_te, y_tr, y_te = train_test_split(X_scaled, y_scaled, test_size=0.2, random_state=42)
    X_tr3 = X_tr.reshape(-1, n_features, 1)
    X_te3 = X_te.reshape(-1, n_features, 1)

    model = build_cnn_lstm(input_shape)
    cb = [
        EarlyStopping(monitor='val_loss', patience=12, restore_best_weights=True, verbose=0),
        ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=6, min_lr=1e-6, verbose=0)
    ]
    history = model.fit(X_tr3, y_tr, epochs=120, batch_size=32,
                        validation_split=0.15, callbacks=cb, verbose=0)

    # Save for next run
    try:
        model.save(MODEL_FILE)
    except Exception:
        pass

    return model, history, X_te3, y_te


# ─────────────────────────────────────────────
# PREDICTION FUNCTION
# ─────────────────────────────────────────────
def predict_runs(meta, model, player, opposition, balls_faced, overs, strike_rate=None):
    df            = meta['df']
    feature_cols  = meta['feature_cols']
    label_encoders= meta['label_encoders']
    scaler_X      = meta['scaler_X']
    scaler_y      = meta['scaler_y']
    n_features    = meta['n_features']

    median_vals = df[feature_cols].median()
    input_dict  = median_vals.to_dict()

    warnings_out = []

    # Encode Player
    if 'Player' in label_encoders and 'Player_enc' in input_dict:
        le = label_encoders['Player']
        known = list(le.classes_)
        match = [p for p in known if player.strip().lower() in p.lower()]
        if match:
            input_dict['Player_enc'] = int(le.transform([match[0]])[0])
        else:
            warnings_out.append(f"Player '{player}' not found — using closest median encoding.")

    # Encode Opposition
    if 'Opposition' in label_encoders and 'Opposition_enc' in input_dict:
        le = label_encoders['Opposition']
        known = list(le.classes_)
        match = [o for o in known if opposition.strip().lower() in o.lower()]
        if match:
            input_dict['Opposition_enc'] = int(le.transform([match[0]])[0])
        else:
            warnings_out.append(f"Opposition '{opposition}' not found — using closest median encoding.")

    if 'BF'    in input_dict: input_dict['BF']    = float(balls_faced)
    if 'Overs' in input_dict: input_dict['Overs'] = float(overs)
    if 'SR'    in input_dict:
        sr = strike_rate if strike_rate else (balls_faced / overs * 6 if overs > 0 else 100)
        input_dict['SR'] = float(sr)

    # Build input array — replace any NaN/inf with 0 before scaling
    arr_vals = []
    for c in feature_cols:
        v = input_dict.get(c, 0)
        if v is None or (isinstance(v, float) and (np.isnan(v) or np.isinf(v))):
            v = 0.0
        arr_vals.append(float(v))

    arr = np.array([arr_vals], dtype=np.float32)

    # Replace any NaN that crept in after array construction
    arr = np.nan_to_num(arr, nan=0.0, posinf=1.0, neginf=0.0)

    arr_scaled = scaler_X.transform(arr)

    # Clip scaled values to [0,1] — out-of-range inputs cause NaN predictions
    arr_scaled = np.clip(arr_scaled, 0.0, 1.0)
    arr_scaled = np.nan_to_num(arr_scaled, nan=0.0)

    arr_seq = arr_scaled.reshape(1, n_features, 1)

    pred_scaled = model.predict(arr_seq, verbose=0).flatten()[0]

    # Guard against NaN/Inf model output
    if np.isnan(pred_scaled) or np.isinf(pred_scaled):
        warnings_out.append("Model returned an invalid prediction — defaulting to dataset average.")
        pred_runs = float(df['Runs'].median()) if 'Runs' in df.columns else 35.0
    else:
        pred_scaled = float(np.clip(pred_scaled, 0.0, 1.0))
        pred_runs   = scaler_y.inverse_transform([[pred_scaled]])[0][0]

    # Final NaN safety check
    if np.isnan(pred_runs) or np.isinf(pred_runs):
        pred_runs = float(df['Runs'].median()) if 'Runs' in df.columns else 35.0

    return max(0, int(round(float(pred_runs)))), warnings_out


# ─────────────────────────────────────────────
# VISUALISATIONS
# ─────────────────────────────────────────────
def plot_training_loss(history):
    fig, ax = plt.subplots(figsize=(8, 3.5))
    fig.patch.set_facecolor('#0d1b2a')
    ax.set_facecolor('#0d1b2a')
    ax.plot(history.history['loss'],     color='#1db954', linewidth=2, label='Train Loss')
    ax.plot(history.history['val_loss'], color='#89c4f4', linewidth=2, linestyle='--', label='Val Loss')
    ax.set_title('CNN-LSTM Training Loss', color='#c8e0ff', fontsize=12, pad=10)
    ax.set_xlabel('Epoch', color='#5a7a9a')
    ax.set_ylabel('MSE Loss', color='#5a7a9a')
    ax.tick_params(colors='#5a7a9a')
    for spine in ax.spines.values():
        spine.set_edgecolor('#1e3a5f')
    ax.legend(facecolor='#0f1e33', labelcolor='#c8e0ff', fontsize=9)
    ax.grid(True, color='#1e3a5f', alpha=0.5)
    plt.tight_layout()
    return fig


def plot_run_distribution(df):
    fig, ax = plt.subplots(figsize=(8, 3.5))
    fig.patch.set_facecolor('#0d1b2a')
    ax.set_facecolor('#0d1b2a')
    bins = np.arange(0, df['Runs'].max() + 10, 10)
    ax.hist(df['Runs'], bins=bins, color='#1db954', alpha=0.7, edgecolor='#0a0e1a', linewidth=0.4)
    ax.set_title('Runs Distribution in Dataset', color='#c8e0ff', fontsize=12, pad=10)
    ax.set_xlabel('Runs', color='#5a7a9a')
    ax.set_ylabel('Frequency', color='#5a7a9a')
    ax.tick_params(colors='#5a7a9a')
    for spine in ax.spines.values():
        spine.set_edgecolor('#1e3a5f')
    ax.grid(True, color='#1e3a5f', alpha=0.5, axis='y')
    plt.tight_layout()
    return fig


def plot_top_scorers(df, top_n=10):
    if 'Player' not in df.columns:
        return None
    top = df.groupby('Player')['Runs'].mean().nlargest(top_n).reset_index()
    fig, ax = plt.subplots(figsize=(8, 4))
    fig.patch.set_facecolor('#0d1b2a')
    ax.set_facecolor('#0d1b2a')
    colors = plt.cm.YlGn(np.linspace(0.4, 0.9, top_n))
    bars = ax.barh(top['Player'], top['Runs'], color=colors, edgecolor='#0a0e1a', linewidth=0.4)
    ax.set_title(f'Top {top_n} Players by Avg Runs', color='#c8e0ff', fontsize=12, pad=10)
    ax.set_xlabel('Average Runs', color='#5a7a9a')
    ax.tick_params(colors='#c8e0ff', labelsize=8)
    for spine in ax.spines.values():
        spine.set_edgecolor('#1e3a5f')
    ax.grid(True, color='#1e3a5f', alpha=0.5, axis='x')
    for bar, val in zip(bars, top['Runs']):
        ax.text(bar.get_width() + 0.5, bar.get_y() + bar.get_height()/2,
                f'{val:.1f}', va='center', color='#89c4f4', fontsize=8)
    plt.tight_layout()
    return fig


# ─────────────────────────────────────────────
# SIDEBAR
# ─────────────────────────────────────────────
with st.sidebar:
    st.markdown("""
    <div style='text-align:center;padding:10px 0 20px 0;'>
        <div style='font-size:2.8rem;'>🏏</div>
        <div style='font-family:Rajdhani,sans-serif;font-size:1.1rem;font-weight:700;
                    color:#89c4f4;letter-spacing:2px;text-transform:uppercase;'>Cricket AI</div>
        <div style='font-size:0.7rem;color:#3a5a7a;letter-spacing:1px;margin-top:2px;'>CNN + LSTM Engine</div>
    </div>
    <hr style='border-color:#1e3a5f;margin:0 0 20px 0;'>
    """, unsafe_allow_html=True)

    st.markdown("""
    <div style='color:#5a7a9a;font-size:0.75rem;letter-spacing:1px;text-transform:uppercase;
                font-weight:600;margin-bottom:10px;'>Dataset Files Required</div>
    """, unsafe_allow_html=True)

    for fname, required in [(BATSMAN_FILE, True), (BOWLER_FILE, False),
                             (ODI_FILE, False), (GROUND_FILE, False)]:
        exists = os.path.exists(fname)
        icon   = "✅" if exists else ("❗" if required else "⚪")
        color  = "#1db954" if exists else ("#ffd700" if required else "#3a5a7a")
        st.markdown(
            f"<div style='font-size:0.78rem;color:{color};padding:3px 0;'>{icon} {fname}</div>",
            unsafe_allow_html=True
        )

    st.markdown("<hr style='border-color:#1e3a5f;margin:20px 0;'>", unsafe_allow_html=True)

    st.markdown("""
    <div style='color:#5a7a9a;font-size:0.75rem;letter-spacing:1px;text-transform:uppercase;
                font-weight:600;margin-bottom:10px;'>Architecture</div>
    <div style='font-size:0.8rem;color:#7a9bbf;line-height:1.9;'>
        🔷 Conv1D (64 → 128 filters)<br>
        🔷 MaxPooling1D<br>
        🔶 LSTM (128 → 64 units)<br>
        🔶 BatchNormalization<br>
        ⬜ Dense (64 → 32 → 1)
    </div>
    <hr style='border-color:#1e3a5f;margin:20px 0;'>
    <div style='font-size:0.72rem;color:#3a5a7a;text-align:center;line-height:1.6;'>
        Model saved as<br>
        <span style='color:#5a7a9a;font-family:monospace;'>cricket_cnn_lstm_model.keras</span><br>
        after first training run
    </div>
    """, unsafe_allow_html=True)


# ─────────────────────────────────────────────
# HERO HEADER
# ─────────────────────────────────────────────
st.markdown("""
<div class="hero-header">
    <div class="hero-title">Cricket Player<br>Performance Predictor</div>
    <div class="hero-subtitle">Deep learning-powered run prediction using CNN + LSTM architecture</div>
    <div class="hero-badge">🤖 AI Powered · CNN + LSTM</div>
</div>
""", unsafe_allow_html=True)


# ─────────────────────────────────────────────
# LOAD DATA
# ─────────────────────────────────────────────
with st.spinner("Loading dataset and preprocessing..."):
    meta, err = load_and_preprocess()

if err:
    st.markdown(f"""
    <div class="warn-box">
        ⚠️ <strong>Dataset Error</strong><br><br>
        {err}<br><br>
        <strong>Steps to fix:</strong><br>
        1. Place <code>Batsman_Data.csv</code> in the same folder as this script.<br>
        2. Optionally add <code>Bowler_data.csv</code>, <code>ODI_Match_Results.csv</code>,
           <code>Ground_Averages.csv</code> for richer predictions.<br>
        3. Re-run: <code>streamlit run cricket_predictor_app.py</code>
    </div>
    """, unsafe_allow_html=True)
    st.stop()

# ─────────────────────────────────────────────
# LOAD / TRAIN MODEL
# ─────────────────────────────────────────────
model_status = st.empty()

if not os.path.exists(MODEL_FILE):
    model_status.info("🏋️ No saved model found — training CNN+LSTM now. This takes ~1–2 minutes and won't repeat.")

with st.spinner("Loading model (or training if first run)..."):
    model, history, X_te3, y_te = get_model(
        meta['n_features'], meta['X_scaled'], meta['y_scaled']
    )

model_status.empty()

# ─────────────────────────────────────────────
# QUICK STATS ROW
# ─────────────────────────────────────────────
df = meta['df']
total_matches = len(df)
total_players = df['Player'].nunique() if 'Player' in df.columns else "—"
avg_runs      = round(df['Runs'].mean(), 1) if 'Runs' in df.columns else "—"
max_runs      = int(df['Runs'].max()) if 'Runs' in df.columns else "—"

c1, c2, c3, c4 = st.columns(4)
for col, val, label in [
    (c1, total_matches, "Total Records"),
    (c2, total_players, "Unique Players"),
    (c3, avg_runs,      "Avg Runs"),
    (c4, max_runs,      "Highest Score"),
]:
    col.markdown(f"""
    <div class="metric-card">
        <div class="metric-value">{val}</div>
        <div class="metric-label">{label}</div>
    </div>
    """, unsafe_allow_html=True)

st.markdown("<br>", unsafe_allow_html=True)


# ─────────────────────────────────────────────
# TABS
# ─────────────────────────────────────────────
tab_pred, tab_model, tab_data = st.tabs(["🏏  Predict Runs", "📊  Model Analytics", "🗂️  Dataset Explorer"])


# ════════════════════════════════════════════
# TAB 1 — PREDICT
# ════════════════════════════════════════════
with tab_pred:
    col_form, col_result = st.columns([1.1, 1], gap="large")

    with col_form:
        st.markdown('<div class="card"><div class="card-title">Match Parameters</div>', unsafe_allow_html=True)

        players_list    = meta['players']    or ["Enter player name manually"]
        oppositions_list = meta['oppositions'] or ["Enter team manually"]

        # Player input
        use_manual_player = st.checkbox("Type player name manually", value=False)
        if use_manual_player or not players_list:
            player_input = st.text_input("Player Name", placeholder="e.g. Virat Kohli")
        else:
            player_input = st.selectbox("Player Name", options=["— Select —"] + players_list)

        # Opposition input
        use_manual_opp = st.checkbox("Type opposition name manually", value=False)
        if use_manual_opp or not oppositions_list:
            opp_input = st.text_input("Opponent Team", placeholder="e.g. Australia")
        else:
            opp_input = st.selectbox("Opponent Team", options=["— Select —"] + oppositions_list)

        col_a, col_b = st.columns(2)
        with col_a:
            balls_faced = st.number_input("Balls Faced", min_value=1, max_value=300, value=40, step=1)
        with col_b:
            overs = st.number_input("Overs", min_value=5.0, max_value=50.0, value=15.0, step=0.1)

        sr_manual = st.number_input("Strike Rate (optional — leave 0 to auto-compute)",
                                     min_value=0.0, max_value=300.0, value=0.0, step=0.1)
        strike_rate = sr_manual if sr_manual > 0 else None

        st.markdown("</div>", unsafe_allow_html=True)
        predict_btn = st.button("⚡  PREDICT RUNS", use_container_width=True)

    with col_result:
        st.markdown('<div class="card"><div class="card-title">Prediction Output</div>', unsafe_allow_html=True)

        if predict_btn:
            # Validate inputs
            player_val = player_input if use_manual_player else (
                player_input if player_input != "— Select —" else "")
            opp_val    = opp_input if use_manual_opp else (
                opp_input if opp_input != "— Select —" else "")

            if not player_val.strip():
                st.markdown('<div class="warn-box">⚠️ Please enter or select a player name.</div>',
                            unsafe_allow_html=True)
            elif not opp_val.strip():
                st.markdown('<div class="warn-box">⚠️ Please enter or select an opponent team.</div>',
                            unsafe_allow_html=True)
            else:
                with st.spinner("Analyzing performance patterns..."):
                    runs, warns = predict_runs(meta, model, player_val, opp_val,
                                               balls_faced, overs, strike_rate)

                for w in warns:
                    st.markdown(f'<div class="warn-box">⚠️ {w}</div>', unsafe_allow_html=True)

                # Performance category
                avg = df['Runs'].mean()
                if runs < avg * 0.7:
                    cat, cat_color = "⚠️ Below Expected", "#ff6b6b"
                elif runs < avg * 1.3:
                    cat, cat_color = "👍 Solid Performance", "#89c4f4"
            
                    
                else:
                    cat, cat_color = "🔥 Outstanding", "#1db954"

                st.markdown(f"""
                <div class="result-box">
                    <div class="result-runs">{runs}</div>
                    <div class="result-label">Predicted Runs</div>
                    <div style='margin:10px 0;'>
                        <span style='background:{cat_color}22;color:{cat_color};
                                     border:1px solid {cat_color}55;border-radius:20px;
                                     font-size:0.75rem;font-weight:700;letter-spacing:1px;
                                     padding:4px 14px;text-transform:uppercase;'>
                            {cat}
                        </span>
                    </div>
                    <div class="result-sentence">
                        <strong style='color:#c8e6d4;'>{player_val}</strong> is predicted to score
                        <strong style='color:#1db954;'>{runs} runs</strong> against
                        <strong style='color:#c8e6d4;'>{opp_val}</strong>
                        facing {balls_faced} balls over {overs} overs.
                    </div>
                </div>
                """, unsafe_allow_html=True)

                # Mini gauge bar
                pct = min(runs / 150, 1.0)
                bar_color = cat_color
                st.markdown(f"""
                <div style='margin-top:18px;'>
                    <div style='display:flex;justify-content:space-between;
                                font-size:0.7rem;color:#5a7a9a;margin-bottom:5px;'>
                        <span>0</span><span>50</span><span>100</span><span>150+</span>
                    </div>
                    <div style='background:#1e3a5f;border-radius:8px;height:10px;overflow:hidden;'>
                        <div style='background:linear-gradient(90deg,#1db954,{bar_color});
                                    width:{int(pct*100)}%;height:100%;border-radius:8px;
                                    transition:width 0.6s ease;'></div>
                    </div>
                    <div style='font-size:0.7rem;color:#5a7a9a;margin-top:4px;text-align:right;'>
                        {runs} / 150
                    </div>
                </div>
                """, unsafe_allow_html=True)
        else:
            st.markdown("""
            <div style='text-align:center;padding:50px 20px;color:#2a4a6b;'>
                <div style='font-size:3rem;margin-bottom:14px;'>🏏</div>
                <div style='font-family:Rajdhani,sans-serif;font-size:1.1rem;letter-spacing:2px;
                            text-transform:uppercase;color:#2a4a6b;'>
                    Fill in the match parameters<br>and click Predict Runs
                </div>
            </div>
            """, unsafe_allow_html=True)

        st.markdown("</div>", unsafe_allow_html=True)


# ════════════════════════════════════════════
# TAB 2 — MODEL ANALYTICS
# ════════════════════════════════════════════
with tab_model:
    st.markdown('<div class="card"><div class="card-title">Model Performance Metrics</div>', unsafe_allow_html=True)

    if X_te3 is not None and y_te is not None:
        y_pred_sc  = model.predict(X_te3, verbose=0).flatten()
        # Clip to valid scaler range to prevent NaN after inverse_transform
        y_pred_sc  = np.clip(y_pred_sc, 0.0, 1.0)
        y_te_clean = np.clip(y_te,      0.0, 1.0)
        y_pred_act = meta['scaler_y'].inverse_transform(y_pred_sc.reshape(-1,1)).flatten()
        y_true_act = meta['scaler_y'].inverse_transform(y_te_clean.reshape(-1,1)).flatten()
        # Remove any residual NaN/Inf pairs before sklearn metrics
        mask = np.isfinite(y_pred_act) & np.isfinite(y_true_act)
        y_pred_act, y_true_act = y_pred_act[mask], y_true_act[mask]
        if len(y_pred_act) == 0:
            st.warning("Not enough valid predictions to compute metrics. Delete cricket_cnn_lstm_model.keras and retrain.")
        else:
            mse  = mean_squared_error(y_true_act, y_pred_act)
            rmse = np.sqrt(mse)
            mae  = mean_absolute_error(y_true_act, y_pred_act)
            r2   = r2_score(y_true_act, y_pred_act)
            mc1, mc2, mc3, mc4 = st.columns(4)
            for col, val, label in [
                (mc1, f"{rmse:.2f}", "RMSE (runs)"),
                (mc2, f"{mae:.2f}",  "MAE (runs)"),
                (mc3, f"{r2:.4f}",   "R² Score"),
                (mc4, f"{mse:.2f}",  "MSE"),
            ]:
                col.markdown(f"""
                <div class="metric-card">
                    <div class="metric-value">{val}</div>
                    <div class="metric-label">{label}</div>
                </div>
                """, unsafe_allow_html=True)
    else:
        st.info("Metrics available after first training run. A saved model was loaded — metrics shown on next run with freshly trained model.")

    st.markdown("</div>", unsafe_allow_html=True)

    col_g1, col_g2 = st.columns(2)

    with col_g1:
        st.markdown('<div class="card"><div class="card-title">Training Loss Curve</div>', unsafe_allow_html=True)
        if history:
            fig = plot_training_loss(history)
            st.pyplot(fig, use_container_width=True)
        else:
            st.info("Training history not available (model was loaded from saved file).")
        st.markdown("</div>", unsafe_allow_html=True)

    with col_g2:
        st.markdown('<div class="card"><div class="card-title">Actual vs Predicted Runs</div>', unsafe_allow_html=True)
        if X_te3 is not None and 'y_pred_act' in dir() and len(y_pred_act) > 0:
            fig2, ax2 = plt.subplots(figsize=(6, 4))
            fig2.patch.set_facecolor('#0d1b2a')
            ax2.set_facecolor('#0d1b2a')
            # Use only finite values for plotting
            _mask = np.isfinite(y_true_act) & np.isfinite(y_pred_act)
            _yt, _yp = y_true_act[_mask], y_pred_act[_mask]
            ax2.scatter(_yt, _yp, alpha=0.45, color='#1db954', edgecolors='#0a0e1a',
                        linewidths=0.3, s=25)
            lim = max(_yt.max(), _yp.max()) + 5
            ax2.plot([0, lim], [0, lim], 'r--', linewidth=1.5, alpha=0.7, label='Perfect fit')
            ax2.set_xlabel('Actual Runs', color='#5a7a9a')
            ax2.set_ylabel('Predicted Runs', color='#5a7a9a')
            ax2.set_title('Actual vs Predicted', color='#c8e0ff', fontsize=11, pad=8)
            ax2.tick_params(colors='#5a7a9a')
            for spine in ax2.spines.values(): spine.set_edgecolor('#1e3a5f')
            ax2.legend(facecolor='#0f1e33', labelcolor='#c8e0ff', fontsize=8)
            ax2.grid(True, color='#1e3a5f', alpha=0.4)
            plt.tight_layout()
            st.pyplot(fig2, use_container_width=True)
        else:
            st.info("Scatter plot available after training run.")
        st.markdown("</div>", unsafe_allow_html=True)


# ════════════════════════════════════════════
# TAB 3 — DATASET EXPLORER
# ════════════════════════════════════════════
with tab_data:
    col_d1, col_d2 = st.columns(2)

    with col_d1:
        st.markdown('<div class="card"><div class="card-title">Runs Distribution</div>', unsafe_allow_html=True)
        fig3 = plot_run_distribution(df)
        st.pyplot(fig3, use_container_width=True)
        st.markdown("</div>", unsafe_allow_html=True)

    with col_d2:
        st.markdown('<div class="card"><div class="card-title">Top Scorers (Avg Runs)</div>', unsafe_allow_html=True)
        fig4 = plot_top_scorers(df)
        if fig4:
            st.pyplot(fig4, use_container_width=True)
        else:
            st.info("Player column not found in dataset.")
        st.markdown("</div>", unsafe_allow_html=True)

    st.markdown('<div class="card"><div class="card-title">Dataset Sample (first 50 rows)</div>', unsafe_allow_html=True)
    display_cols = [c for c in ['Player', 'Opposition', 'Runs', 'BF', 'SR', 'Overs', 'Country']
                    if c in df.columns]
    st.dataframe(
        df[display_cols].head(50).reset_index(drop=True),
        use_container_width=True,
        height=320
    )
    st.markdown(f"<div style='font-size:0.75rem;color:#3a5a7a;margin-top:8px;'>"
                f"Showing 50 of {len(df):,} records · {len(df.columns)} columns</div>",
                unsafe_allow_html=True)
    st.markdown("</div>", unsafe_allow_html=True)
